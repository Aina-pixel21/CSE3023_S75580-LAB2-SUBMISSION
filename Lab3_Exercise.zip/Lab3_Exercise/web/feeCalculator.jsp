<%-- 
    Document   : feeCalculator
    Created on : Apr 14, 2026, 4:07:22?PM
    Author     : Admin
--%>

<%@ include file="header.jsp" %>

<h3>Membership Fee Calculator</h3>

<form method="post">
    Number of Activities:
    <input type="number" name="activities" required>
    <input type="submit" value="Calculate">
</form>

<%
    if(request.getParameter("activities") != null) {
        int activities = Integer.parseInt(request.getParameter("activities"));
        double total = activities * 10.0;
%>

<p>Total Fee: RM <%= String.format("%.2f", total) %></p>

<%
    }
%>

<%@ include file="footer.jsp" %>
