<%-- 
    Document   : memberDirectory
    Created on : Apr 14, 2026, 4:07:51?PM
    Author     : Admin
--%>

<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>

<h3>Club Member Directory</h3>

<%
    // Get member list from application scope
    ArrayList<String> members = (ArrayList<String>) application.getAttribute("members");

    // If no data yet, create default list
    if(members == null){
        members = new ArrayList<String>();
        members.add("Maisarah (Programming Club)");
        members.add("Batrisyia (Multimedia Club)");
        members.add("Murni (Robotics Club)");
        members.add("Aina (Programming Club)");
        members.add("Dayana (Multimedia Club)");

        application.setAttribute("members", members);
    }
%>

<table border="1" cellpadding="10" style="margin-top:20px;">
    <tr>
        <th>No</th>
        <th>Name & Club</th>
    </tr>

<%
    if(!members.isEmpty()){
        for(int i = 0; i < members.size(); i++){
%>
    <tr>
        <td><%= i + 1 %></td>
        <td><%= members.get(i) %></td>
    </tr>
<%
        }
    } else {
%>
    <tr>
        <td colspan="2">No members registered yet.</td>
    </tr>
<%
    }
%>

</table>

<%@ include file="footer.jsp" %>