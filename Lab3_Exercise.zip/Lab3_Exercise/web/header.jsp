<%-- 
    Document   : header
    Created on : Apr 14, 2026, 4:03:52 PM
    Author     : Admin
--%>

<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Student Club System</title>
    <style>
        body { 
            font-family: Times New Roman; 
            margin: 0; 
            background-color: #f8f5ff;
        }

        header { 
            background-color: #b39ddb; 
            padding: 15px; 
            color: white; 
        }

        table {
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
        }

        footer {
            background-color: #ede7f6;
        }
    </style>
</head>
<body>

<header>
    <h2>Student Club Registration System</h2>
    <nav>
        <a href="registerClub.jsp">Registration Page</a>
        <a href="feeCalculator.jsp">Fee Calculator</a>
        <a href="memberDirectory.jsp">Club Member Directory</a>
    </nav>
</header>
<hr>