<%-- 
    Document   : footer
    Created on : Apr 14, 2026, 4:05:18?PM
    Author     : Admin
--%>

<hr>
<footer style="text-align:center; padding:10px;">
    <p>&copy; 2026 Faculty of Computer Science & Mathematics, UMT</p>
</footer>

</body>
</html>