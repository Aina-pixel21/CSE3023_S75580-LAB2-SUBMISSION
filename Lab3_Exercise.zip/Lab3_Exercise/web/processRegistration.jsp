<%-- 
    Document   : processRegistration
    Created on : Apr 14, 2026, 4:06:45?PM
    Author     : Admin
--%>

<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>

<%
    String name = request.getParameter("name");
    String matric = request.getParameter("matric");
    String club = request.getParameter("club");

    // Get existing list from application scope
    ArrayList<String> members = (ArrayList<String>) application.getAttribute("members");

    if(members == null){
        members = new ArrayList<String>();
    }

    // Add new member
    members.add(name + " (" + club + ")");

    // Save back to application scope
    application.setAttribute("members", members);
%>

<h3>Registration Successful</h3>
<p><b>Name:</b> <%= name %></p>
<p><b>Matric No:</b> <%= matric %></p>
<p><b>Club:</b> <%= club %></p>

<a href="memberDirectory.jsp">View Member Directory</a>

<%@ include file="footer.jsp" %>