<%-- 
    Document   : registerClub
    Created on : Apr 14, 2026, 4:05:59?PM
    Author     : Admin
--%>

<%@ include file="header.jsp" %>

<h3>Club Registration Form</h3>

<form action="processRegistration.jsp" method="post">
    Name: <input type="text" name="name" required><br><br>
    Matric No: <input type="text" name="matric" required><br><br>

    Select Club:
    <select name="club">
        <option value="Programming Club">Programming Club</option>
        <option value="Multimedia Club">Multimedia Club</option>
        <option value="Robotics Club">Robotics Club</option>
    </select><br><br>

    <input type="submit" value="Register">
</form>

<%@ include file="footer.jsp" %>
